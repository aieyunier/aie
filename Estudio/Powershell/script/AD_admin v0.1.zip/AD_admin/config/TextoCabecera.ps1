write-host "
************************************************************************* 
****  HERRAMIENTA PARA LA ADMINISTRACION DE ACTIVE DIRECTORY  V_1.0   ****
************************************************************************* 
                                                     yunier.valdes@aie.es 
"
