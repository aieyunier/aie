$test = "ok"

function eventViewer {
    param (
        $domainController = "europa",
        $user="",
        $eventID=4624,
        $maxEvent= 100
    )
    if ([string]::IsNullOrWhiteSpace($user)) {
        $xpathFilter = "*[System[EventID=$eventID]]"
    } else {$xpathFilter = "*[System[EventID=$eventID]] and *[EventData[Data[@Name='TargetUserName']='$user']]"}

    $eventLog = Get-WinEvent -ComputerName $domainController -LogName Security -MaxEvents $maxEvent -FilterXPath $xpathFilter 
    write-host $eventLog.Length
    if ($eventLog.Length -gt 0){
        foreach ($event in $eventLog) {
            $xml = [xml]$event.ToXml()
            $userName = $xml.Event.EventData.Data | Where-Object {$_.Name -eq 'TargetUserName'} | Select-Object -ExpandProperty '#text'
            #$computerName = $xml.Event.EventData.Data | Where-Object {$_.Name -eq 'WorkstationName'} | Select-Object -ExpandProperty '#text'
            $computerIP = $xml.Event.EventData.Data | Where-Object {$_.Name -eq 'IpAddress'} | Select-Object -ExpandProperty '#text'
            $errorCode = $xml.Event.EventData.Data | Where-Object {$_.Name -eq 'Status_Code'} | Select-Object -ExpandProperty '#text'

            Write-Host "Evento ID: $($event.Id)"
            Write-Host "Registro: $($event.LogName)"
            Write-Host "Hora de evento: $($event.TimeCreated)"
            Write-Host "Usuario: $userName"
            #Write-Host "Computadora: $computerName"
            Write-Host "Direccion IP: $computerIP"
            #Write-Host "Cdigo de estado: $errorCode"
            Write-Host "------------------------"
        }
    }else{write-host "No hay eventos con ID $eventID para el usuario $user"}    
}

