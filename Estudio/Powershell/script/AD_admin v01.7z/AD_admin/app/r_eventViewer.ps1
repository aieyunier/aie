########
# poner en el fichero de funciones y eliminar al final 
######
$contenidoFunciones = Get-Content -Path .\app\funciones2.ps1 -Raw
Invoke-Expression -Command $contenidoFunciones 
###############################################################################
# Visor de eventos
###############################################################################
clear-host
Write-host "#################################################################"
Write-host "########      	 VISOR DE EVENTOS DEL AD		          #######"
Write-host "#################################################################"
write-host "............................................by Yunier Valdes 2023"


write-host "Seleccione la opcion para el filtrado del registro de eventos"
write-host "(1) Eventos de inicio de sesion exitosos"
write-host "(2) Eventos de inicio de sesion fallidos"
write-host "(3) Eventos de bloqueo de cuentas"
write-host "(4) Eventos de reseteo de claves"
write-host " "
write-host "(0) Cancelar y Reresar"
write-host " "
$operacion = read-host "Operacion"

if($operacion -ne 0){ #si la opcion seleccionada no es la de regresar
	if ($operacion -ge 1 -and $operacion -le 4){ ## si se selecciona una opcion de la lista
		switch ($operacion) {
			1 { 
				$select=Read-host "
				(1) Ultimos 100 eventos registrados
				(2) Ultimos 100 eventos de un usuario determinado
				selecciones"
				if ($select -eq 1){ eventViewer -eventID 4624}else {
					$usuarioSeleccionado = seleccionarUsuarioAD -credenciales $credenciales
					eventViewer -eventID 4624 -user $usuarioSeleccionado
				}
				$accion = "Visor de eventos"
				$mensaje = "revision de logs de inicio de sesion de u suario $usuarioSeleccionado "
			}
			2 {  
				$usuarioSeleccionado = seleccionarUsuarioAD -credenciales $credenciales
				$accion = "desbloqueo de cuenta"
				$mensaje = "Se desbloqueo la cuenta de usuario: "
				# Desbloquear la cuenta
				Unlock-ADAccount -Credential $credenciales -Identity $usuarioSeleccionado
			}
			3 {  
				$usuarioSeleccionado = seleccionarUsuarioAD -credenciales $credenciales
				$accion = "habilitacion de cuenta"
				$mensaje = "Se habilito la cuenta de usuario: "
				# Habilitar el usuario
				Enable-ADAccount -Credential $credenciales -Identity $usuarioSeleccionado
			}
			4 { 
				$usuarioSeleccionado = seleccionarUsuarioAD -credenciales $credenciales
				$accion = "deshabilitacion de cuenta"
				$mensaje = "Se deshabilito la cuenta de usuario: "
				# Deshabilitar el usuario
				Disable-ADAccount -Credential $credenciales -Identity $usuarioSeleccionado
			}
			5 {  
				$newUser = intDatosNewUser
				$ouPath = SeleccionarOU
				# Definir los detalles del nuevo usuario
				$nombreUsuario = $newUser.Nombre
				$contrasena = ConvertTo-SecureString $newUser.Clave -AsPlainText -Force
				$nombreCompleto = $newUser.Nombre + " " + $newUser.Apellido1 + " " + $newUser.Apellido2
				$apellidos = $newUser.Apellido1 + " " + $newUser.Apellido2
				$nombreUsuarioSam = $newUser.Cuenta  # Nombre de inicio de sesión (debe ser único)
				$mail = $newUser.Correo 
				# Crear el nuevo usuario en la OU especificada
				New-ADUser -Name $nombreCompleto -DisplayName $nombreCompleto -EmailAddress $mail -Surname $apellidos -AccountPassword $contrasena -Enabled $true -GivenName $nombreUsuario -SamAccountName $nombreUsuarioSam -UserPrincipalName "$nombreUsuarioSam@dominio.com" -Path $ouPath
				$accion = "Creacion de cuenta"
				$mensaje = "Se creo la cuenta de usuario: "
				$usuarioSeleccionado = $nombreUsuarioSam

			}
			6 {  
				$usuarioSeleccionado = seleccionarUsuarioAD -credenciales $credenciales
				$accion = "eliminacion de cuenta"
				$mensaje = "Se elimino la cuenta de usuario: "
				Remove-ADUser -Credential $credenciales -Identity $usuarioSeleccionado 

			}
			7 {  
				$usuarioSeleccionado = seleccionarUsuarioAD -credenciales $credenciales
				$accion = "revision de cuenta"
				$mensaje = "Se reviso el estdo de la cuenta de usuario: "
				Get-ADUser -Credential $credenciales -Filter "SamAccountName -eq '$usuarioSeleccionado'" -properties $adUserProperties				
			}
			Default {}
			
		} 
		write-host "****************************************************************************************"
		#####################################################################################################
		# Log de operacion
		#####################################################################################################
		$mensaje += $usuarioSeleccionado
		RegistrarLog -usuario $nombreUsuario -accion $accion -mensaje $mensaje
		#####################################################################################################
	}else {write-host "Opcion Invalida"}	
}

